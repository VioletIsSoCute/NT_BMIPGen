#%%
from pyomo.environ import Var, Binary, Reals, ConcreteModel, ConstraintList, Objective, minimize, SolverFactory, Param
import pandas as pd
import numpy as np
import json
import os
#%%
def load_problem(folder, model, default_bounds=(-10, 10)):
    # Load parameters from metadata.json
    with open(os.path.join(folder, 'metadata.json'), 'r') as f:
        parameters = json.load(f)

    model.x_ud = Var(range(parameters["x_ud"]), domain=Reals, bounds=default_bounds)
    model.x_uc = Var(range(parameters["x_uc"]), domain=Reals, bounds=default_bounds)
    model.x_ld = Var(range(parameters["x_ld"]), domain=Reals, bounds=default_bounds)
    model.x_lc = Var(range(parameters["x_lc"]), domain=Reals, bounds=default_bounds)
    
    model.y_ud = Var(range(parameters["y_ud"]), domain=Binary, bounds=default_bounds)
    model.y_uc = Var(range(parameters["y_uc"]), domain=Binary, bounds=default_bounds)
    model.y_ld = Var(range(parameters["y_ld"]), domain=Binary, bounds=default_bounds)
    model.y_lc = Var(range(parameters["y_lc"]), domain=Binary, bounds=default_bounds)

    # Initialize constraints list
    model.constraints = ConstraintList()

    # Constraints
    xs = ["x_ud","y_ud"]
    if sum([parameters[i] for i in xs])!=0:
        g_file = 'G_ud'
        A = pd.read_csv(os.path.join(folder, f"{g_file}_A.csv")).values
        b = pd.read_csv(os.path.join(folder, f"{g_file}_b.csv")).values.flatten()
        size = b.size
        k = np.cumsum(np.array([parameters[i] for i in xs]))
        for i in range(size):
            # Sum for the first part (model.x_ud)
            expr1 = sum(A[i, j] * model.x_ud[j] for j in range(k[0]))
            # Sum for the second part (model.y_ud)
            expr2 = sum(A[i, j] * model.y_ud[j - k[0]] for j in range(k[0], k[1]))
            # Add the constraint to the ConstraintList
            model.constraints.add(expr = expr1 + expr2 <= b[i])
    
    xs = ["x_ld","y_ld"]
    if sum([parameters[i] for i in xs])!=0:
        g_file = 'g_ld'
        A = pd.read_csv(os.path.join(folder, f"{g_file}_A.csv")).values
        b = pd.read_csv(os.path.join(folder, f"{g_file}_b.csv")).values.flatten()
        size = b.size
        k = np.cumsum(np.array([parameters[i] for i in xs]))
        for i in range(size):
            # Sum for the first part (model.x_ld)
            expr1 = sum(A[i, j] * model.x_ld[j] for j in range(k[0]))
            # Sum for the second part (model.y_ld)
            expr2 = sum(A[i, j] * model.y_ld[j - k[0]] for j in range(k[0], k[1]))
            # Add the constraint to the ConstraintList
            model.constraints.add(expr = expr1 + expr2 <= b[i])

    xs = ["x_ud","y_ud","x_uc","y_uc"]
    if sum([parameters[i] for i in xs])!=0:
        g_file = 'G_uc'
        A = pd.read_csv(os.path.join(folder, f"{g_file}_A.csv")).values
        b = pd.read_csv(os.path.join(folder, f"{g_file}_b.csv")).values.flatten()
        size = b.size
        k = np.cumsum(np.array([parameters[i] for i in xs]))
        for i in range(size):
            # Sum for the first part (model.x_ud)
            expr1 = sum(A[i, j] * model.x_ud[j] for j in range(k[0]))
            # Sum for the second part (model.y_ud)
            expr2 = sum(A[i, j] * model.y_ud[j - k[0]] for j in range(k[0], k[1]))
            # Sum for the second part (model.x_uc)
            expr3 = sum(A[i, j] * model.x_uc[j - k[1]] for j in range(k[1], k[2]))
            # Sum for the second part (model.y_uc)
            expr4 = sum(A[i, j] * model.y_uc[j - k[2]] for j in range(k[2], k[3]))
            # Add the constraint to the ConstraintList
            model.constraints.add(expr = expr1 + expr2 + expr3 + expr4 <= b[i])

    
    xs = ["x_ld","y_ld","x_lc","y_lc"]
    if sum([parameters[i] for i in xs])!=0:
        g_file = 'g_lc'
        A = pd.read_csv(os.path.join(folder, f"{g_file}_A.csv")).values
        b = pd.read_csv(os.path.join(folder, f"{g_file}_b.csv")).values.flatten()
        size = b.size
        
        k = np.cumsum(np.array([parameters[i] for i in xs]))
        for i in range(size):
            # Sum for the first part (model.x_ld)
            expr1 = sum(A[i, j] * model.x_ld[j] for j in range(k[0]))
            # Sum for the second part (model.y_ld)
            expr2 = sum(A[i, j] * model.y_ld[j - k[0]] for j in range(k[0], k[1]))
            # Sum for the second part (model.x_lc)
            expr3 = sum(A[i, j] * model.x_lc[j - k[1]] for j in range(k[1], k[2]))
            # Sum for the second part (model.y_lc)
            expr4 = sum(A[i, j] * model.y_lc[j - k[2]] for j in range(k[2], k[3]))
            # Add the constraint to the ConstraintList
            model.constraints.add(expr = expr1 + expr2 + expr3 + expr4 <= b[i])
    
    xs = ["x_uc","y_uc","x_lc","y_lc"]
    if sum([parameters[i] for i in xs])!=0:
        g_file = 'g_g'
        A = pd.read_csv(os.path.join(folder, f"{g_file}_A.csv")).values
        b = pd.read_csv(os.path.join(folder, f"{g_file}_b.csv")).values.flatten()
        size = b.size
        k = np.cumsum(np.array([parameters[i] for i in xs]))
        for i in range(size):
            # Sum for the first part (model.x_uc)
            expr1 = sum(A[i, j] * model.x_uc[j] for j in range(k[0]))
            # Sum for the second part (model.y_uc)
            expr2 = sum(A[i, j] * model.y_uc[j - k[0]] for j in range(k[0], k[1]))
            # Sum for the second part (model.x_lc)
            expr3 = sum(A[i, j] * model.x_lc[j - k[1]] for j in range(k[1], k[2]))
            # Sum for the second part (model.y_lc)
            expr4 = sum(A[i, j] * model.y_lc[j - k[2]] for j in range(k[2], k[3]))
            # Add the constraint to the ConstraintList
            model.constraints.add(expr = expr1 + expr2 + expr3 + expr4 <= b[i])
        
    # Objective
    F_pu, F_pl, F_mu, ff_pl, ff_ml = 0, 0, 0, 0, 0

    xs = ["x_ud","y_ud"]
    if sum([parameters[i] for i in xs])!=0:
        obj_file = 'F_u'
        o = pd.read_csv(os.path.join(folder, f"{obj_file}.csv")).values.flatten()
        
        k = np.cumsum(np.array([parameters[i] for i in xs]))
        size = o.size
        expr1 = sum(o[j]* model.x_ud[j] for j in range(k[0]))
        expr2 = sum(o[j]* model.y_ud[j-k[0]] for j in range(k[0],k[1]))
        F_pu = expr1 + expr2

    xs = ["x_ld","y_ld"]
    if sum([parameters[i] for i in xs])!=0:
        obj_file = 'F_l'
        o = pd.read_csv(os.path.join(folder, f"{obj_file}.csv")).values.flatten()
        size = o.size
        k = np.cumsum(np.array([parameters[i] for i in xs]))
        expr1 = sum(o[j]* model.x_ld[j] for j in range(k[0]))
        expr2 = sum(o[j]* model.y_ld[j-k[0]] for j in range(k[0],k[1]))
        F_pl = expr1 + expr2

    xs = ["x_uc","y_uc","x_lc","y_lc"]
    if sum([parameters[i] for i in xs])!=0:
        obj_file = 'F_c'
        o = pd.read_csv(os.path.join(folder, f"{obj_file}.csv")).values.flatten()
        size = o.size
        k = np.cumsum(np.array([parameters[i] for i in xs]))
        expr1 = sum(o[j]* model.x_uc[j] for j in range(k[0]))
        expr2 = sum(o[j]* model.y_uc[j-k[0]] for j in range(k[0],k[1]))
        expr3 = sum(o[j]* model.x_lc[j-k[1]] for j in range(k[1],k[2]))
        expr4 = sum(o[j]* model.y_lc[j-k[2]] for j in range(k[2],k[3]))
        F_mu=expr1 + expr2 + expr3 + expr4


    xs = ["x_ld","y_ld"]
    if sum([parameters[i] for i in xs])!=0:
        obj_file = 'ff_l'
        o = pd.read_csv(os.path.join(folder, f"{obj_file}.csv")).values.flatten()
        size = o.size
        k = np.cumsum(np.array([parameters[i] for i in xs]))
        expr1= sum(o[j]* model.x_ld[j] for j in range(k[0]))
        expr2= sum(o[j]* model.y_ld[j-k[0]] for j in range(k[0],k[1]))
        ff_pl=expr1 + expr2

    xs = ["x_uc","y_uc","x_lc","y_lc"]
    if sum([parameters[i] for i in xs])!=0:
        obj_file = 'ff_c'
        o = pd.read_csv(os.path.join(folder, f"{obj_file}.csv")).values.flatten()
        size = o.size
        k = np.cumsum(np.array([parameters[i] for i in xs]))
        expr1 = sum(o[j]* model.x_uc[j] for j in range(k[0]))
        expr2 = sum(o[j]* model.y_uc[j-k[0]] for j in range(k[0],k[1]))
        expr3 = sum(o[j]* model.x_lc[j-k[1]] for j in range(k[1],k[2]))
        expr4 = sum(o[j]* model.y_lc[j-k[2]] for j in range(k[2],k[3]))
    ff_ml = expr1 + expr2 + expr3 + expr4

    model.upper_objective = F_pu + F_pl + F_mu
    model.lower_objective = ff_pl + ff_ml
    
    
    model.objective = Objective(expr=model.upper_objective, sense=minimize)
#%%
# # Example usage
# mymodel = ConcreteModel()
# load_problem('problem_3',model=mymodel)
# # Solve
# solver = SolverFactory('gurobi')
# solver.solve(mymodel)

# # Display results
# mymodel.display()
# %%
# Fixes upper variables to its previously solved value
def fixed_upper(model):
    upper_params = [model.x_uc, model.y_uc, model.x_ud, model.y_ud]
    for upper_param in upper_params:
        if len(upper_param)!=0:
            for i in upper_param:
                upper_param[i].fix(upper_param[i].value)  
def setlowerobj(model):
    model.objective.set_value(model.lower_objective)
def unfixed_upper(model): 
    upper_params = [model.x_uc, model.y_uc, model.x_ud, model.y_ud]
    for upper_param in upper_params:
        if len(upper_param)!=0:
            for i in upper_param:
                upper_param[i].unfix() 
#%%
"""# Example usage
mymodel = ConcreteModel()
load_problem('problem_3',model=mymodel)
# Solve
solver = SolverFactory('gurobi')
solver.solve(mymodel)
# Display results
# mymodel.display()
print(f"relaxed opt. obj:{mymodel.objective()}")
#fixed upper
fixed_upper(model=mymodel)
solver = SolverFactory('gurobi')
solver.solve(mymodel)
# Display results
# mymodel.display()
print(f"relaxed feas. obj:{mymodel.objective()}")"""
# %%
