#%%
from problem_loading import load_problem, fixed_upper, setlowerobj
from problem＿generator import generate_problem
from pyomo.environ import ConcreteModel, SolverFactory
from tqdm import tqdm
import json
import shutil
import os
#%%
def Triviality_calculate(parameters, problems_name = "problems_folder", N_eval=30, solver_name="gurobi"):
    count = 0
    # Create the folder if it doesn't exist
    if not os.path.exists(problems_name):
        os.makedirs(problems_name)

    # Change to the folder
    os.chdir(problems_name)

    # Wrap the loop with tqdm for a progress bar
    for i in tqdm(range(N_eval), desc="Evaluating Problems"):
        problem_name = f"problem_{i - count + 1}"
        # Generate the problem
        generate_problem(problem_name, parameters)

        # Load the problem into the Pyomo model
        mymodel = ConcreteModel()
        load_problem(problem_name, model=mymodel)

        # Solve the relaxed optimization problem
        solver = SolverFactory(solver_name)
        solver.solve(mymodel)
        RO_Obj = mymodel.objective()

        # Solve the fixed upper-level problem
        fixed_upper(model=mymodel)
        setlowerobj(model=mymodel)
        solver.solve(mymodel)
        RF_Obj = mymodel.upper_objective()

        # Calculate the gap
        gap = RF_Obj - RO_Obj

        # Check for triviality
        if abs(gap) < 1e-6:
            # Remove trivial problem folder
            if os.path.exists(problem_name):
                shutil.rmtree(problem_name)
            count += 1
            continue

        # Write RO_Obj, RF_Obj, and Gap into metadata.json
        metadata_file = os.path.join(problem_name, "metadata.json")
        metadata = {}
        if os.path.exists(metadata_file):
            with open(metadata_file, "r") as file:
                metadata = json.load(file)
        metadata["RO_Obj"] = RO_Obj
        metadata["RF_Obj"] = RF_Obj
        metadata["Gap"] = gap
        with open(metadata_file, "w") as file:
            json.dump(metadata, file, indent=4)

    # Return to the original directory
    os.chdir("..")

    # Print the triviality percentage
    trivial_percentage = count / N_eval * 100
    print(f"Trivial %: {trivial_percentage:.2f}%")
    return trivial_percentage
#%%
def nontrivial_BMIP_generator(parameters, N_gen=10, I=3, problems_name = "problems_folder", solver_name="gurobi"):
    count_trivial = 0  # Counter for trivial cases
    count_nontrivial = 0  # Counter for non-trivial cases
    max_iterations = I * N_gen  # Maximum iterations allowed

    # Create the folder if it doesn't exist
    if not os.path.exists(problems_name):
        os.makedirs(problems_name)

    # Change to the folder
    os.chdir(problems_name)

    # Wrap the loop with tqdm for a progress bar
    with tqdm(total=N_gen, desc="Generating Non-Trivial Cases") as pbar:
        for iteration in range(max_iterations):
            problem_name = f"problem_{count_nontrivial+1}"
            
            # Generate the problem
            generate_problem(problem_name, parameters)

            # Load the problem into the Pyomo model
            mymodel = ConcreteModel()
            load_problem(problem_name, model=mymodel)

            # Solve the relaxed optimization problem
            solver = SolverFactory(solver_name)
            solver.solve(mymodel)
            RO_Obj = mymodel.objective()

            # Solve the fixed upper-level problem
            fixed_upper(model=mymodel)
            setlowerobj(model=mymodel)
            solver.solve(mymodel)
            RF_Obj = mymodel.upper_objective()

            # Calculate the gap
            gap = RF_Obj - RO_Obj

            # Check for triviality
            if abs(gap) < 1e-6:
                # Remove trivial problem folder
                if os.path.exists(problem_name):
                    shutil.rmtree(problem_name)
                count_trivial += 1
            else:
                # Write RO_Obj, RF_Obj, and Gap into metadata.json
                metadata_file = os.path.join(problem_name, "metadata.json")
                metadata = {}
                if os.path.exists(metadata_file):
                    with open(metadata_file, "r") as file:
                        metadata = json.load(file)
                metadata["RO_Obj"] = RO_Obj
                metadata["RF_Obj"] = RF_Obj
                metadata["Gap"] = gap
                with open(metadata_file, "w") as file:
                    json.dump(metadata, file, indent=4)
                
                # Count as a non-trivial case
                count_nontrivial += 1
                pbar.update(1)  # Update progress bar

            # Stop if we have generated enough non-trivial cases
            if count_nontrivial >= N_gen:
                break

            # Stop if max_iterations is reached
            if iteration + 1 >= max_iterations:
                print(f"Reached maximum iterations ({max_iterations}).")
                break

    # Return to the original directory
    os.chdir("..")

    # Print statistics
    trivial_percentage = count_trivial / iteration * 100 if iteration > 0 else 0
    print(f"Trivial %: {trivial_percentage:.2f}%")
    print(f"Non-Trivial Cases Generated: {count_nontrivial}/{N_gen}")
    return trivial_percentage, count_nontrivial


