# NT_BMIPGen

NT_BMIPGen is a Python library for generating bilevel mixed integer problems.

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install foobar.

```bash
pip install NT_BMIPGen
```

## Usage
N_gen: number of nontrivial bilevel mixed integer problems you want to generate
I: The break parameters if not enough feasible solution after I*N_gen evaluations
N_eval: number of evaluations

Function:
1. nontrivial_BMIP_generator make nontrivial problem folders, including the number of problems you want to generate, return trivial percent and number of constructed problems.
2. Triviality_calculate make nontrivial problem folders, including the nontrivial problems in the problems you evaluate, returns triviality.
```python
import NT_BMIPGen

# Make nontrivial problem folders, return trivial percent and number of constructed problems
parameters = {
    'x_ud':0, 'y_ud': 0, 'x_uc': 20, 'y_uc': 0,
    'x_ld': 0, 'y_ld': 0, 'x_lc': 20, 'y_lc': 0,
    'G_ud': 0, 'g_ld': 0, 'G_uc': 0, 'g_lc': 0, 'g_g': 20
}
nontrivial_BMIP_generator(parameters, N_gen=5, I=5, problems_name = "problems_folder", solver_name="gurobi")

# Make nontrivial problem folders, returns triviality
Triviality_calculate(parameters, problems_name = "problems_folder", N_eval=30, solver_name="gurobi")
```

## Contributing

Pull requests are welcome. For major changes, please open an issue first
to discuss what you would like to change.

Please make sure to update tests as appropriate.

## License

[MIT](https://choosealicense.com/licenses/mit/)